//~~~~~~~~~ Setting Owner~~~~~~~~~~//
global.prefix = [".", "!", ".", ",", "🐤", "🗿"]; 
global.publik = true
global.owner = ["62881027516652"] 
global.namabot = 'DELTA CRASH V3'
//~~~~~~~~~ Setting ~~~~~~~~~~//
global.namach = "DENZ INFORMATION FREE SCRIPT "
global.link = "https://whatsapp.com/channel/0029Vb6RRs40rGiDSkUp5l2f"
global.idch = "120363420387327565@newsletter"
global.imgthumb = "https://files.catbox.moe/yhy9bo.jpg"
global.vidthumb = "https://files.catbox.moe/x9id78.mp4"
//~~~~~~~~~ Setting Mess ~~~~~~~~~~//
global.mess = { 
owner: '𝖪𝗁𝗎𝗌𝗎𝗌 𝖮𝗐𝗇𝖾𝗋',
premium: '𝖪𝗁𝗎𝗌𝗎𝗌 𝖯𝗋𝖾𝗆𝗂𝗎𝗆',
succes: '𝖲𝗎𝖼𝖼𝖾𝗌𝗌𝖿𝗎𝗅'
//~~~~~~~~~ End ~~~~~~~~~~//
}